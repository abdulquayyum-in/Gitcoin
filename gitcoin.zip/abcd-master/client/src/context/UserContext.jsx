import { createContext,useReducer } from "react";
//importing context from react
import UserReducer from "./UserReducer"
import axios from "axios";
import { Navigate } from "react-router-dom";
//instantiate
const UserContext = createContext()

export const UserProvider = ({children})=>{
  const initialState = {
    user: {},
    loading: false,
    allRepos:[],
    yourtasks:[],
    searchName:''
  }
  const [state,dispatch] = useReducer(UserReducer,initialState)
  const setUser = (data)=>{
   try {
    dispatch({
      type:'SET_USER_DATA',
      payload: data,
    })
   } catch (error) {
    console.log(error)
   }   
}
//Change search userName
const setSearchUser = (name)=>{
  dispatch({
    type:'SET_SEARCH_USERNAME',
    payload: name,
  })
}


//Get Data and Set Data
const getDataAndSet = async ()=>{
  try {
    const token = JSON.parse(localStorage.getItem('token'));    
  const {data} = await axios.get(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/info`, {
    headers:{
      "auth-token" : token
    }
  }) 
  setUser(data.obj)   
  return false
} catch (error) {
    console.log("Hi")
  return true
  }
}

async function getAndSetYourTasks(){
  const token = JSON.parse(localStorage.getItem('token'));
  console.log("Token:"+token)
  let {data} = await axios.get(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/task/yourtasks`,{
    headers:{
      "auth-token" : token
    }
  }) 
  dispatch({
    type:'SET_YOUR_TASKS',
    payload: data.yourTasks,
  })
  console.log(typeof(data))
  console.log(data.yourTasks)

}
  
  return <UserContext.Provider value={{
    user: state.user,
    loading: state.loading,
    setUser,
    repos: state.repos,
    getDataAndSet,
    allRepos : state.allRepos,
    getAndSetYourTasks,
    yourtasks: state.yourtasks,
    searchName: state.searchName,
    setSearchUser
  }
  }>
    {children}
  </UserContext.Provider>
}
export default UserContext