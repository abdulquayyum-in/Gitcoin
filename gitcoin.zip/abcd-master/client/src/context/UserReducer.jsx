function UserReducer(state,action){
  switch(action.type){
    case 'SET_USER_DATA':
      return {
        ...state,
        user : action.payload.userData,
        loading: false,
        allRepos:action.payload.userrepo
      }
    case 'SET_LOADING':
        return {
          ...state,
          loading: true,
        }
        case 'SET_YOUR_TASKS':
          return {
            ...state,
            loading: true,
            yourtasks: action.payload
          }
        case 'SET_SEARCH_USERNAME':
          return {
            ...state,
            loading: true,
            searchName: action.payload
          }
    default:
        state
      }
  }

  export default UserReducer