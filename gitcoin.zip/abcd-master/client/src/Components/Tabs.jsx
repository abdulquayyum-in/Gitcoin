import { Routes,Route } from "react-router-dom";
import { Navigate, useNavigate } from "react-router-dom";
import MyTasks from "../Components/Tasks/MyTasks"

import AssignedTasks from "../Components/Tasks/AssignedTask"
import Navbars from "./Navbars";
import MiddleTasks from "./Tasks/MiddleTasks";
import Wallet from "./money/wallet";
import Footer from "./Footer"

function Tabs(){
   const navigate= useNavigate()

const onClick=()=>{
   navigate('/tasks/mytasks')
}

const Assign=()=>{
   navigate('/tasks/assigntask')
}
const Modal=()=>{
   navigate('/tasks/createtask')
}

return(
  
   <> 
   <div style={{backgroundColor:"#0A2647"}} className="w-full" >
      <Navbars/>
      
 
   <ul className="flex flex-wrap text-base font-medium text-center text-gray-500 m-6 mt-20  border-b border-white ">
   <li className="mr-2">
   <button  onClick={onClick} className="inline-block p-2 text-xl w-30 mx-5 ml-20 text-white rounded-t-lg hover:text-pink-600 " > My Jobs
      </button>
   </li>
   <li className="mr-2">
   <button  onClick={Assign}className="inline-block p-2 text-xl  w-30 mx-5 ml-20 text-white rounded-t-lg hover:text-pink-600" > Assigned Jobs
      </button>
   </li>
   <li className="mr-2">
   <button  onClick={Modal} className="inline-block p-2 text-xl  w-30 mx-5 ml-20 text-white rounded-t-lg hover:text-pink-600 " > Create Jobs
      </button>
   </li>   
  </ul>

  <Routes>
   <Route path="tasks" element={<MyTasks/>}/>
   <Route path="/mytasks" element={<MyTasks/>}/>
   {/* If this is not ok then use MiddleTasks */}
   <Route path="/assigntask" element={<AssignedTasks/>}/>
   <Route path="/createtask" element={<MiddleTasks/>}/>
   
  </Routes>
  <Footer/>
  </div>
  </>
   
    )
}

export default Tabs;