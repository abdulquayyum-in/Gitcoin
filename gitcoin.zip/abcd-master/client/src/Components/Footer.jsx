

import React from 'react'

function Footer() {
  return (
<div style={{backgroundColor:"#0A2647"}} className="h-screen">
hello
</div>
  )
}

export default Footer