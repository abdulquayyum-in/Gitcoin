import { useState} from "react";
import axios from "axios";
import Wallet from "./Wallet.jsx"
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';



const Credit=()=>{
const [money, setMoney]= useState("")
console.log(money)
const onChangeHandler=(e)=>{
  setMoney({
  ...money,
  [e.target.name]: +(e.target.value)
  }
  )
 }
console.log(typeof(money))

const onSubmitHandler = async(e)=>{
  try{
    e.preventDefault();
    const token = JSON.parse(localStorage.getItem('token')); 
    let {data}= await axios.post(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/updatewallet`, money, {
      headers:{
      'auth-token': token
      }
    })
   
  }
  catch(error){
  console.log(error);
  }
}

function paywithRazor(){
 const amount = document.getElementById("money").value;
 console.log(amount)
  var options = {
  "key": "rzp_test_BdAPWnfgT2EBxy",
  "amount": amount * 100, // amount in paise
  "currency": "INR",
  "name": "Gitcoin",
  "description": "Test Transaction",
  "image": "https://your-company-logo.png",
  "handler": function (response){
    toast.success(`${amount} has been added to your wallet`);
  },
  "prefill": {
    "name": "John Doe",
    "email": "john@example.com",
    "contact": "9999999999"
  },
  "notes": {
    "address": "Razorpay Corporate Office"
  },
  "theme": {
    "color": "#F37254"
  }
};
var rzp1 = new Razorpay(options);
rzp1.open();
e.preventDefault();
}

  return(
        <main id="content" role="main" className="w-full max-w-md mx-auto p-6">
        <div className=" bg-white  rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700 mt-7 ">
          <div className="p-4 sm:p-7">
            <div className="text-center">
              <h1 style={{color:"#f000b8" }}className="block text-lg font-bold text-gray-800">Credit your account here</h1><br/>
              <Wallet/>
            </div>
            <div className="mt-5">
              <form onSubmit={onSubmitHandler}><ToastContainer/>
                <div className="grid gap-y-4">
                  <div>
                    <label htmlFor="money" className="block text-sm font-bold ml-1 mb-2 dark:text-white">Amount</label>
                    <div className="relative">
                      <input type="number" id="money" name="money"  onChange={onChangeHandler} className="py-3 px-4 block w-full border-2 border-gray-200 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500 shadow-sm" required  />
                    </div>
                  </div>
                </div>
                <div style={{  display: 'flex',   alignItems: 'center',  justifyContent: 'center'}}>
                <button style={{backgroundColor:"#f000b8" }} type="submit" onClick={paywithRazor} className="focus:outline-none m-4 focus:ring-2 focus:ring-offset-2 focus:ring-indigo-700 transition duration-150 ease-in-out hover:bg-indigo-600 bg-indigo-700 rounded text-white px-8 py-2 text-sm">Submit</button>
                </div>
              
              </form>
            </div>
          </div>
        </div>
        
      </main>





       )
    
}
export default Credit