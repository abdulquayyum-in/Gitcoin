import { useState } from "react"
import axios from "axios";
import Wallet from "./Wallet.jsx";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

function Debit(){

  const onClickHandler = async(e)=>{
    e.preventDefault();
    try{
      const token = JSON.parse(localStorage.getItem('token')); 
      let {data}= await axios.post(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/debitwallet`, debitData, {
        headers:{
        'auth-token': token
        }
      })
      console.log(data)
      toast("Amount will be tranferred to your account in 3-4 days")
     
    }
    catch(error){
    console.log(error);
    }
  }
    const[debitData, setDebitData]= useState({
        name: "",
        accountnumber:"",
        money:""  
      })
      let { name, accountnumber, money}= debitData;
      const onChangeHandler=(e)=>{
        setDebitData({
          ...debitData,
          [e.target.name] : +e.target.value
        })
      }
      
    return(
    <>
    <main id="content" role="main" className="w-full max-w-md mx-auto p-6">
            <div className=" bg-white  rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700 mt-7">
              <div className="p-4 sm:p-7">
                <div className="text-center">
                <div class="w-full flex justify-start text-gray-600 mb-3">
            
                 </div>
                <h1 style={{color:"#f000b8" }} class=" font-lg text-lg font-bold tracking-normal leading-tight mb-4">Account Details</h1>
                </div>
                <Wallet/>
                <form onSubmit={onClickHandler}><ToastContainer/>
                <label for="name" class="text-gray-800 text-sm font-bold leading-tight tracking-normal">Owner Name</label>
                <input id="name"  name="name" class="mb-5 mt-2 text-gray-600 focus:outline-none focus:border focus:border-indigo-700 font-normal w-full h-10 flex items-center pl-3 text-sm border-gray-300 rounded border" onChange={onChangeHandler} placeholder="Name" />
                   <label for="accountnumber" class="text-gray-800 text-sm font-bold leading-tight tracking-normal">Account Number</label>
                   <div class="relative mb-5 mt-2">
                       <input id="accountnumber"  name="accountnumber"  class="text-gray-600 focus:outline-none focus:border focus:border-indigo-700 font-normal w-full h-10 flex items-center pl-16 text-sm border-gray-300 rounded border" onChange={onChangeHandler} placeholder="XXXX - XXXX - XXXX - XXXX" />
                   </div>
                   
                   
                   <label for="amount" class="text-gray-800 text-sm font-bold leading-tight tracking-normal">Amount</label>
                   <div class="relative mb-5 mt-2">
                     
                       <input id="amount" name="money" class="mb-8 text-gray-600 focus:outline-none focus:border focus:border-indigo-700 font-normal w-full h-10 flex items-center pl-3 text-sm border-gray-300 rounded border" onChange={onChangeHandler} placeholder="Amount" />
                   </div>
                   <div class="flex items-center justify-start w-full">
                       <button style={{backgroundColor:"#f000b8" }} className="focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-700 transition duration-150 ease-in-out hover:bg-indigo-600 bg-indigo-700 rounded text-white px-8 py-2 text-sm" type="submit">Submit</button>
                     
                   </div>
                </form>
                
            </div>
            </div>
          </main>
    
    
    </>
    )
    }
    export default Debit