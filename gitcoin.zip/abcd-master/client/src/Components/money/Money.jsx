import { Routes,Route } from "react-router-dom";
import { Navigate, useNavigate } from "react-router-dom";
import Navbars from "../Navbars";
import Debit from "./Debit";
import Credit from "./Credit";
import Transactions from "./Transactions";
import Footer from "../Footer";
function Money(){
   const navigate= useNavigate()

const onClick=()=>{
   navigate('/account/transaction')
}
const Assign=()=>{
   navigate('/account/credit')
}
const Modal=()=>{
   navigate('/account/debit')
}


return(
<> 
<div style={{backgroundColor:"#0A2647"}} className="w-full" >
<Navbars/>
   <ul className="flex flex-wrap text-sm font-medium text-center text-gray-500 m-6 mt-20  border-b border-gray-200 ">
   <li className="mr-2">
   <button onClick={onClick} className="inline-block p-2 text-base w-30 mx-5 ml-20 rounded-t-lg text-pink-600 bg-gray-50 " > Transaction History
      </button>
   </li>
   <li className="mr-2">
   <button  onClick={Assign} className="inline-block p-2 text-base w-30 mx-5 ml-20  rounded-t-lg text-pink-600 bg-gray-50" > Add Money
      </button>
   </li>
   <li className="mr-2">
   <button onClick={Modal} className="inline-block p-2 text-base w-30 mx-5 ml-20  rounded-t-lg text-pink-600 bg-gray-50 " > Withdraw Money
      </button>
   </li>   
    
  </ul>

  <Routes>
   <Route path="account" element={<Transactions/>}/>
   <Route path="/debit" element={<Debit/>}/>
   <Route path="/credit" element={<Credit/>}/>
   <Route path="/transaction" element={<Transactions/>}/>

   
  </Routes>
  <Footer/>
  </div>
  </>
   
    )
}

export default Money;