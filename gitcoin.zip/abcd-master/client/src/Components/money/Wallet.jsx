import {useState} from 'react'
import { useEffect } from 'react'
import axios from 'axios'
import { TfiWallet } from "react-icons/tfi";
const Wallet = () => {
        const [wallet, setWallet]=useState('')
        
        useEffect(()=>{ 
          let getWallet= async()=>{
          try{
            const token = JSON.parse(localStorage.getItem('token')); 
            let {data}= await axios.get(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/wallet`,  {
              headers:{
              'auth-token': token
              }
            })
            console.log((data.userwallet))
            setWallet (data.userwallet)
          }
          catch(error){
            console.log(error)
          }
        }
     getWallet();
        },[]);
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
 <div className='stat-figure text-secondary'>
     <TfiWallet className='text-3xl md:text-3xl' /> 
       </div>
                <div style={{color:"#0A2647"}} className=' pr-5 text-xl md:text-xl m-3'>  {wallet}
                  </div>
                </div>
    
    
  )
}

export default Wallet