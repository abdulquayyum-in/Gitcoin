import React from 'react'
import { useState } from 'react'
import axios from 'axios'
import { useEffect } from 'react'

const Transactions = () => {

const [transaction, setTransactions]=useState([])
const  getTheDate=(theDate)=>{
let date = new Date(theDate)
let str = ''
str = date.getDate() +"-"+ date.getMonth() +"-" +date.getFullYear()
return str
}
useEffect(()=>{
  let getDetails = async ()=>{
    try {
    const token = JSON.parse(localStorage.getItem('token')); 
    let {data}= await axios.get(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/transaction`,  {
      headers:{
      'auth-token': token
      }
    })
    console.log(data.usertransaction)
    setTransactions(data.usertransaction) 
    } 
    catch (error) {
        console.error(error);
      }
    }
    getDetails();
},[]);



return (
  <>
<div style={{  display: 'flex',   alignItems: 'center',  justifyContent: 'center'}}>
<div class="overflow-hidden rounded-lg border border-gray-200 shadow-md mt-7">
<table class="w-full border-collapse bg-white text-center text-sm text-gray-500">
  <thead class="bg-gray-50">
    <tr>
      <th scope="col" class="px-20 py-4 font-medium text-gray-900">Date</th>
      <th scope="col" class="px-20 py-4 font-medium text-gray-900">Credited</th>
      <th scope="col" class="px-20 py-4 font-medium text-gray-900">Debited</th>
      <th scope="col" class="px-15 py-4 font-medium text-gray-900">Balance</th>
    </tr>
  </thead>
  <tbody class="divide-y divide-gray-100 border-t border-gray-100">
    {
    transaction.slice(0).reverse().map((item)=>(
             <tr class="hover:bg-gray-50">
                    <th class="flex gap-3 px-6 py-4 font-normal text-gray-900">
                      <div className="text-sm text-center">
                        <div class="font-medium text-center text-gray-700">{getTheDate(item.date)}</div>
                      </div>
                    </th>
                    <td class="px-6 py-4">
                    <div class="flex gap-2 text-gray-700">
                        <p className='text-center'>{item.credited}</p>
                      </div>
                    </td>
                    <td class="px-6 py-4">
                      <div class="flex gap-2 text-gray-700">
                        <p text-center>{item.debited}</p>
                      </div>
                    </td>
                    <td class="px-6 py-4">
                      <div class="flex justify-end gap-4 text-gray-700">
                        <p>{item.balance}GC</p>
                      </div>
                    </td>
                    
                  </tr>


    ))
    }
  
   
</tbody>
</table>
</div>
</div>
</>

  )
}

export default Transactions