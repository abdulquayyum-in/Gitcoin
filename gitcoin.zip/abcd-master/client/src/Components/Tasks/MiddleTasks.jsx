import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';


function MiddleTasks(){
  const[repoName, setRepoName]= useState([])
  const[taskData, setTaskData]= useState({
    username: "",
    taskname: "",
    repo: "",
    reward: "",
    deadline: "",
    description: "",
    
  })
  let { username, taskname, repo, reward, deadline, description}= taskData;
  const onChangeHandler=(e)=>{
    setTaskData({
      ...taskData,
      [e.target.name] : e.target.value
    })
  }

 

  useEffect(()=>{ 
    let getRepoNames= async()=>{
    try{
      const token = JSON.parse(localStorage.getItem('token')); 
      let {data}= await axios.get(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/repodata`,  {
        headers:{
        'auth-token': token
        }
      })
      console.log(data.allrepodata)
      setRepoName(data.allrepodata)
    
    }
    catch(error){
      console.log(error)
    }
  }
    getRepoNames();
  },[]);
  

  
  const onSubmitHandler = async(e)=>{
   
    try{
    e.preventDefault();
    const token = JSON.parse(localStorage.getItem('token')); 
    const {data}= await axios.post(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/task/assigntask`, taskData, {
      headers:{
      'auth-token': token
      }
    })
    console.log(data);
    toast.success(data.success)
   
    }

    catch(error){
    console.log(error.response.data);
    toast.error(error.response.data.error);
    }
  }

  return (
<>
  {/* <div id="defaultModal" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div class="relative w-full h-full max-w-2xl md:h-auto">
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">   
            <div class="flex items-start justify-between p-4 border-b rounded-t dark:border-gray-600">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                    Your Account Balance
                </h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="defaultModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
        </div>
    </div>
</div>  */}

<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <main id="content" role="main" className="w-full max-w-md mx-auto mb-2">
    <div className="mt-7 bg-white  rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700">
      <div className="p-4 sm:p-7">
        <div className="text-center">
          <h1 className="block text-2xl font-bold text-pink-500 dark:text-white">Job Details</h1>
          {/* <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            <a className="text-blue-600 decoration-2 hover:underline font-medium" href="#">
              Login here
            </a>
          </p> */}
        </div>
        <div className="mt-5">
        <form onSubmit={onSubmitHandler}><ToastContainer/>
         <div className="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">User Name</label>
                      <input type="text" name="username" id="username" defaultValue={"Zoha Fatima Ahmed"} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" onChange={onChangeHandler} value={username} placeholder="Ex. Mojombo" />
                    </div>
                    <div>
                      <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Job Name</label>
                      <input type="text" name="taskname" id="taskname" defaultValue={"GitCoin"} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" onChange={onChangeHandler} value={taskname} placeholder="Ex. Gitcoin" />
                    </div>
                    <div>
                    <label htmlFor="repo" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Repositories</label>
                    <select name="repo" id="repo" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" onChange={onChangeHandler}  placeholder="Ex. Gitcoin" >
                    {
                        repoName.map((item)=>(
                        <option  value ={item.repoName} selected>{item.repoName}</option>
                        ))
                      }
                    </select>
                    </div>
                    <div>
                      <label htmlFor="price" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Price</label>
                      <input type="number" defaultValue={399} name="reward" id="price" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" onChange={onChangeHandler} value={reward} placeholder="$299" />
                    </div>
                    <div>
                      <label htmlFor="deadline" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Deadline</label>
                      <input type="datetime-local" id="deadline" name="deadline"  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500  dark:focus:border-primary-500" defaultValue={"Raise PR, Collect Money"} onChange={onChangeHandler} value={deadline}  />
                    </div>
                    <div className="sm:col-span-2">
                      <label htmlFor="description" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                      <textarea id="description"name="description" rows={5} className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Write a description..." defaultValue={"Raise PR, Collect Money"} value={description} onChange={onChangeHandler}  />                    
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <button  style={{backgroundColor:"#f000b8"}} data-modal-target="defaultModal" data-modal-toggle="defaultModal" type="submit" className="text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">
                      Submit
                    </button>
    
                  </div>
                </form>
        </div>
      </div>
    </div>
   
  </main>
  </div>  </>
      
    );
  }

export default MiddleTasks