
import { Link } from 'react-router-dom';
import React, { useState } from 'react'
import {useNavigate} from "react-router-dom"
import {useContext} from "react"
import UserContext from '../context/UserContext';
import Wallet from './money/wallet';
import PrivateRoute from './PrivateRoutes';
export default function Navbars() {
  const navigate = useNavigate()
  const [theSearchName,setTheSearchName] = useState("")
  const {setSearchUser,searchName} = useContext(UserContext)
  const signoutonclick = ()=>{
    localStorage.removeItem("token")
    navigate("/login")
  }
  const func = (e)=>{
    e.preventDefault()   
    setSearchUser(theSearchName)
    navigate(`/search?username=${theSearchName}`)
  }
  const onchange = (e)=>{
    e.preventDefault()
    setTheSearchName(e.target.value)
  }
  useEffect(() => {
  PrivateRoute()
  }, [])
  
  
  return (
<>

<nav  style={{backgroundColor:"#0A2647"}} class=" border-gray-200 px-4 sm:px-2 py-10  dark:bg-gray-900">
  <div class="container flex flex-wrap items-center justify-between mx-auto">
  <a href="#" class="flex items-center">
      <img src="https://res.cloudinary.com/dgjmrmajh/image/upload/v1677232230/Screenshot_from_2023-02-24_13-09-34_hfqxrq.png" class="h-6 mr-3 sm:h-9" alt="GitCoin Logo" />
      <span class="self-center text-5xl font-semibold whitespace-nowrap text-white">GITCOIN</span>
  </a>
  <div class="flex md:order-2">
    
    <button type="button" data-collapse-toggle="navbar-search" aria-controls="navbar-search" aria-expanded="false" class="md:hidden text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 rounded-lg text-sm p-2.5 mr-1" >
      <svg class="w-5 h-5" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd"></path></svg>
      <span class="sr-only">Search</span>
    </button>
    
    <div class="relative hidden md:block">
      <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
        <svg class="w-5 h-5 text-black" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd"></path></svg>
        <span class="sr-only">Search icon</span>
      </div>
      <form action="" onSubmit={func}>
      <input type="text" id="search-navbar" class="block w-full p-2 pl-10 text-sm text-black border border-gray-300 rounded-lg bg-gray-50 focus:ring-pink-500 focus:border-pink-500 dark:bg-gray-700 dark:border-gray-600 placeholder-black  dark:focus:ring-pink-500 dark:focus:border-pink-500" placeholder="Search User" hidefocus="true" onChange={onchange}/>
      </form>
    </div>
    
  </div>
    <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-search">
      <div class="relative mt-3 md:hidden">
        
        <input type="text" id="search-navbar" class="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg  focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search..."/>
      </div>
      <ul  style={{backgroundColor:"#0A2647"}} class="flex flex-col p-2 mt-4 border border-gray-100 rounded-lg  md:flex-row md:space-x-16 md:mt-0 md:text-sm md:font-medium md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
        <li>
        <Link class="block py-2 pl-3 pr-4 ml-2 mr-1 text-white text-xl rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-pink-500 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700" to="/home">Profile</Link>
        </li>
        <Link class="block py-2 pl-3 pr-4 ml-1 mr-1 text-white text-xl  rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-pink-500 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700" to="/tasks/mytasks">Manage Jobs</Link>
        <li>
   <Link class="block py-2 pl-3 pr-4 ml-1 mr-1 text-white text-xl rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-pink-500 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700" to="/account/transaction">Manage Money</Link>
   </li>
  <li>
     <a href="mailto:ahmedzoha12@gmail.com" class="block py-2 pl-3 pr-4 text-white text-xl  ml-1 mr-2  rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-pink-500 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">Contact</a>
   </li>
   <li class="block py-2 pl-3 pr-4 text-white text-xl  ml-1 mr-2 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-pink-500 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">
   <button onClick={signoutonclick}>
    Sign out
    </button>
   </li>
      </ul>
    </div>
  </div>
</nav>
</>

)}