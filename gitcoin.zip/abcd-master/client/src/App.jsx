import './App.css';
import Login from './pages/Login';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom"
import Home from './pages/Home';
import {UserProvider} from "./context/UserContext"
import Tabs from './Components/Tabs';
import Money from "./Components/money/Money"
import Search from './pages/Search';
import NotFound from './pages/NotFound';
import PublicUserProfile from './pages/PublicUserProfile';
import PrivateRoute from './Components/PrivateRoutes';
function App() {
  return (
   <>
   <UserProvider>   
  <Router>        
      <Routes>
       
        <Route path="/login" element={<Login/>} />        
        <Route path='/*' element={<NotFound/>}/>
      <Route element={<PrivateRoute />}>
      <Route path='/home' element={<Home />} />
      <Route path="/tasks/*" element={<Tabs/>}/>
        <Route path='/account/*' element={<Money/>}/>
        <Route path='/search*' element={<Search/>}/>
        <Route path='/user*' element={<PublicUserProfile/>}/>
</Route>
</Routes>
    </Router>    
   </UserProvider>
   </>
  );
}

export default App;
