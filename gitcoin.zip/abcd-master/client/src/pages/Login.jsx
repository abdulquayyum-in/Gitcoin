import {React,useContext} from 'react'
import { useState,useEffect} from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom";
import UserContext from '../context/UserContext';
import { FaColumns } from 'react-icons/fa';
import gitimage from "../assets/GitCoin.png"
import Divider from '@mui/material/Divider';
import GitHubIcon from '@mui/icons-material/GitHub';
import git from "../assets/bg.png.jpeg"
import Footer from '../Components/Footer';
const CLIENT_ID = "ae04520c5971bac86b8c"
const serveripaddress = import.meta.env.VITE_SERVER_IP_ADDRESS
const REDIRECT_URI=`${import.meta.env.VITE_CLIENT_IP_ADDRESS}/login/`
const SCOPE = "repo%20user"
let value = 1
function loginwithgithub(e){
  e.preventDefault()
  value++
  window.location.assign(`https://github.com/login/oauth/authorize?client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}&scope=${SCOPE}`)
}
function Login() {
  let navigate = useNavigate()
  let [loginstate, setloginstate] = useState({
    username: "",
    password: ""
  })
  let {user,setUser} = useContext(UserContext)

  const onchange = (e) => {
    e.preventDefault()
    setloginstate({
      ...loginstate,
      [e.target.name]: e.target.value
    })
  }

  const onclick = async (e) => {
    e.preventDefault()
    try {
      console.log("This is from sign-in")
      let {data} = await axios.post(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/login`,loginstate)
      localStorage.setItem('token', JSON.stringify(data.token));
        console.log(data.token)
        navigate("/home")
    } catch (error) {
      console.error(error)
    }
  }
  const [githubSignupClicked, setGithubSignupClicked] = useState(false);
  const handleGithubSignupClick = () => {
    setGithubSignupClicked(true);
   };

  useEffect(()=>{
    const querystring = window.location.search;
    const urlparams = new URLSearchParams(querystring)
    let codeParam = urlparams.get("code")
    if(codeParam==null){
      codeParam = false
    }
    if(codeParam){
      async function data(){
        let {data} = await axios.post(`${serveripaddress}/api/user/verified?code=${codeParam}`)      

        localStorage.setItem('token', JSON.stringify(data.token));
        console.log(data.token)
        navigate("/home")
      }
      data()
    }   
  },[user])
  return (
    <>

      <div  style={{backgroundColor:"#0A2647"}} className=" flex justify-center items-center h-screen w-screen flex-col ...;">
      <img src={gitimage} className="img-fluid" alt="Logo" width="200" height="200" marginTop="30px"></img><br/><br/>          
        <form className="bg-white shadow-md rounded px-20 pt-6 pb-8 m-0" onSubmit={onclick}>
        <h1 style={{color:"#f000b8"}} className="  text-2xl font-bold ">Sign in to your Account</h1><br /><br />
          <div className="mb-4">
            <label className="block text-gray-700 font-bold mb-2" htmlFor="email">
              Username
            </label>
            <input className="shadow appearance-none border rounded w-full py-2 px-5 mb-2 mt-2 text-black leading-tight focus:outline-none focus:shadow-outline" id="email" type="text" placeholder=" Enter your username" onChange={onchange} name="username" />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700 font-bold mb-2" htmlFor="password">
              Password
            </label>
            <input className="shadow appearance-none border border-red-500 rounded w-full py-2 px-5 mb-4 mt-2 text-black leading-tight focus:outline-none focus:shadow-outline" id="password" type="password" placeholder="Enter your password" onChange={onchange} name="password"/>
            <p className="text-red-500 text-xs italic"></p>
          </div>
          <div style={{display: "flex", alignItems: "center",justifyContent: "center"}}>
          <div className="flex-col space-x-2 items-center justify-between px-8 pt-2 pb-8 mb-2">
            <button style={{backgroundColor:"#f000b8"}} className=" hover:bg-zinc-500 text-white font-bold py-2 px-20 mb-2 rounded focus:outline-none focus:shadow-outline;" type="submit">
              Sign In
            </button> 
            <div style={{marginTop:"10px", marginBottom:"10px",}}><Divider>Or continue with </Divider></div>
            <div style={{display: "flex", alignItems: "center",justifyContent: "center"}} >
            <button className="bg-gray-900 hover:bg-zinc-500 text-white items-center font-bold py-2 px-20 rounded focus:outline-none focus:shadow-outline" variant="outlined" startIcon={<GitHubIcon />} onClick={loginwithgithub}>
           <GitHubIcon/>
            </button></div> 
          </div>
          </div>
        </form>
      </div>
      <Footer/>
    </>
  )
}

export default Login