import Navbar from '../Components/Navbars'
import Footer from '../Components/Footer'
import {FaUserFriends, FaUsers} from 'react-icons/fa'
import {useEffect,useContext,React, useState} from 'react'
import UserContext from '../context/UserContext'
import { useNavigate } from 'react-router-dom'
import Spinner from '../../src/assets/index.gif'
import RepoList from './RepoList'
import axios from 'axios'
export default function PublicUserProfile() {
  const {user,getDataAndSet,allRepos} = useContext(UserContext)
  const [theuserData,setTheUserData] = useState('')
  const [theRepoData,setTheRepoData] = useState('')
  //This will get the user data and set it in the user state
  let navigate = useNavigate()
  let userFound = false
  useEffect(() => {
    async function getSearchData() {
      const querystring = window.location.search;
      const urlparams = new URLSearchParams(querystring)
      let userParam = urlparams.get("user")
      const token = JSON.parse(localStorage.getItem('token'));
      // console.log("Token:" + token)
      // console.log("This is the search name")
      // console.log(userParam)
      let response = await axios.get(`${import.meta.env.VITE_SERVER_IP_ADDRESS}/api/user/info/${userParam}`, {
        headers: {
          "auth-token": token
        }
      })
            
      setTheUserData(response.data.userData)      
      setTheRepoData(response.data.repositories)      
    }
    getSearchData()
  }, [])
  const {
    avatar_url,
    bio,
    blog,
    followers,
    following,    
    hireable,
    html_url,
    location,
    login,
    name,    
    public_gists,
    public_repos,    
    twitter_username,    
    type,
    websiteUrl
      } = theuserData
      // if(loading){
      //   return (
      //     <Spinner/>
      //   )
      // }
      return (
        <div  style={{backgroundColor:"#0A2647"}}>
        <Navbar/>
        <div className='w-full mx-auto lg:w-10/12'>
            <div  className='mb-10'>
             
            </div>
    
            <div className='grid grid-cols-1 xl:grid-cols-3 lg:grid-cols-3 md:grid-cols-3 mb-8 md:gap-8'>
              <div className='custom-card-image round-lg shadow-xl mb-6 md:mb-0'>
                <div className=' shadow-xl card image-full'>
                  <figure>
                    <img src={avatar_url} alt='user avatar' />
                  </figure>
                  <div className='card-body justify-end'>
                    <h2 className='card-title mb-0'>{name}</h2>
                    <p className='flex-grow-0'>{login}</p>
                  </div>
                </div>
              </div>
    
              <div  style={{color:"white"}} className='col-span-2'>
                <div className='mb-6'>
                  <h1  style={{color:"white"}} className='text-3xl card-title'>
                    {name}
                    <div  style={{color:"white"}} className='ml-2 mr-1 badge badge-success'>{type}</div>
                    {hireable && (
                      <div className='mx-1 badge badge-info'>Hireable</div>
                    )}
                  </h1>
                  <p  style={{color:"white"}}c>  {bio}</p>
                  <div  style={{color:"white"}} className='mt-4 card-actions space-x-10'>
                    <a   style={{color:"white", }}
                      href={html_url}
                      target='_blank'
                      rel='noreferrer'
                      className='btn btn-outline hover:bg-pink-500'
                    >
                      Visit Github Profile
                    </a>
                 
                  </div>
                </div>
            
    
                <div className='w-full rounded-lg shadow-md bg-white stats'>
                  {location && (
                    <div className='stat'>
                      <div className='stat-title text-md'>Location</div>
                      <div className='text-lg stat-value'>{location}</div>
                    </div>
                  )}
                  {blog && (
                    <div className='stat'>
                      <div className='stat-title text-md'>Website</div>
                      <div className='text-lg stat-value'>
                        <a href={websiteUrl} target='_blank' rel='noreferrer'>
                          {websiteUrl}
                        </a>
                      </div>
                    </div>
                  )}
                  {twitter_username && (
                    <div className='stat'>
                      <div className='stat-title text-md'>Twitter</div>
                      <div className='text-lg stat-value'>
                        <a
                          href={`https://twitter.com/${twitter_username}`}
                          target='_blank'
                          rel='noreferrer'
                        >
                          {twitter_username}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
    
            <div className='w-full py-5 mb-6 rounded-lg shadow-md bg-white stats'>
              <div className='grid grid-cols-1 md:grid-cols-3'>
                <div className='stat'>
                  <div className='stat-figure text-secondary'>
                    <FaUsers className='text-3xl md:text-5xl' />
                  </div>
                  <div className='stat-title pr-5'>Followers</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {followers}
                  </div>
                </div>
    
                <div className='stat'>
                  <div className='stat-figure text-secondary'>
                    <FaUserFriends className='text-3xl md:text-5xl' />
                  </div>
                  <div className='stat-title pr-5'>Following</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {following}
                  </div>
                </div>
    
                <div className='stat'>
                  <div className='stat-title pr-5'>Public Repos</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {public_repos}
                  </div>
                </div>
    
                <div className='stat'>
                  <div className='stat-title pr-5'>Public Gists</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {public_gists}
                  </div>
                </div>
              </div>
            </div>
            
            {/* <RepoList repos ={theRepoData}/> */}
          </div>
          <Footer/>
        </div>
      )
  // return (
  //   <>
  //   
  //     </>
  // )
}

/*
 * Front end side se backend:
 * to whome
 * by who
 * what
 * rating(1-10)
 */