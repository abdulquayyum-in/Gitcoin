import Navbar from '../Components/Navbars'
import Footer from '../Components/Footer'
import {FaCodepen, FaStore, FaUserFriends, FaUsers} from 'react-icons/fa'
import {useEffect,useContext,useState,React} from 'react'
import UserContext from '../context/UserContext'
import {useParams,Link} from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import Spinner from '../../src/assets/index.gif'
import axios from 'axios'
import RepoList from './RepoList'
import Wallet from '../Components/money/wallet'
export default function Home() {
  const {user,getDataAndSet,allRepos} = useContext(UserContext)
  //This will get the user data and set it in the user state
  let navigate = useNavigate()
  let a = 1



  useEffect(()=>{
    const fun = async ()=>{
        if(await getDataAndSet()){  
          console.log("Hello")        
          navigate("/login")
        }
    }
    fun()    
  },[])
  const {
    avatar_url,
    bio,
    blog,
    collaborators,
    company,
    created_at,
    disk_usage,
    email,
    events_url,
    followers,
    followers_url,
    following,
    following_url,
    gists_url,
    gravatar_id,
    hireable,
    html_url,
    id,
    location,
    login,
    name,
    node_id,
    organizations_url,
    owned_private_repos,
    plan,
    private_gists,
    public_gists,
    public_repos,
    received_events_url,
    repos_url,
    site_admin,
    starred_url,
    subscriptions_url,
    total_private_repos,
    twitter_username,
    two_factor_authentication,
    type,
    updated_at,
    url,
    websiteUrl
      } = user
      // if(loading){
      //   return (
      //     <Spinner/>
      //   )
      // }
      return (
        <div  style={{backgroundColor:"#0A2647"}}>
        <Navbar/>
        <div className='w-full mx-auto lg:w-10/12'>
            <div  className='mb-10'>
             
            </div>
    
            <div className='grid grid-cols-1 xl:grid-cols-3 lg:grid-cols-3 md:grid-cols-3 mb-8 md:gap-8'>
              <div className='custom-card-image round-lg shadow-xl mb-6 md:mb-0'>
                <div className=' shadow-xl card image-full'>
                  <figure>
                    <img src={avatar_url} alt='user avatar' />
                  </figure>
                  <div className='card-body justify-end'>
                    <h2 className='card-title mb-0'>{name}</h2>
                    <p className='flex-grow-0'>{login}</p>
                  </div>
                </div>
              </div>
    
              <div  style={{color:"white"}} className='col-span-2'>
                <div className='mb-6'>
                  <h1  style={{color:"white"}} className='text-3xl card-title'>
                    {name}
                    <div  style={{color:"white"}} className='ml-2 mr-1 badge badge-success'>{type}</div>
                    {hireable && (
                      <div className='mx-1 badge badge-info'>Hireable</div>
                    )}
                  </h1>
                  <p  style={{color:"white"}}c>  {bio}</p>
                  <div  style={{color:"white"}} className='mt-4 card-actions space-x-10'>
                    <a   style={{color:"white", }}
                      href={html_url}
                      target='_blank'
                      rel='noreferrer'
                      className='btn btn-outline hover:bg-pink-500'
                    >
                      Visit Github Profile
                    </a>
                 
                  </div>
                </div>
            
    
                <div className='w-full rounded-lg shadow-md bg-white stats'>
                  {location && (
                    <div className='stat'>
                      <div className='stat-title text-md'>Location</div>
                      <div className='text-lg stat-value'>{location}</div>
                    </div>
                  )}
                  {blog && (
                    <div className='stat'>
                      <div className='stat-title text-md'>Website</div>
                      <div className='text-lg stat-value'>
                        <a href={websiteUrl} target='_blank' rel='noreferrer'>
                          {websiteUrl}
                        </a>
                      </div>
                    </div>
                  )}
                  {twitter_username && (
                    <div className='stat'>
                      <div className='stat-title text-md'>Twitter</div>
                      <div className='text-lg stat-value'>
                        <a
                          href={`https://twitter.com/${twitter_username}`}
                          target='_blank'
                          rel='noreferrer'
                        >
                          {twitter_username}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
    
            <div className='w-full py-5 mb-6 rounded-lg shadow-md bg-white stats'>
              <div className='grid grid-cols-1 md:grid-cols-3'>
                <div className='stat'>
                  <div className='stat-figure text-secondary'>
                    <FaUsers className='text-3xl md:text-5xl' />
                  </div>
                  <div className='stat-title pr-5'>Followers</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {followers}
                  </div>
                </div>
    
                <div className='stat'>
                  <div className='stat-figure text-secondary'>
                    <FaUserFriends className='text-3xl md:text-5xl' />
                  </div>
                  <div className='stat-title pr-5'>Following</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {following}
                  </div>
                </div>
    
                <div className='stat'>
                  <div className='stat-title pr-5'>Public Repos</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {public_repos}
                  </div>
                </div>
    
                <div className='stat'>
                  <div className='stat-title pr-5'>Public Gists</div>
                  <div className='stat-value pr-5 text-3xl md:text-4xl'>
                    {public_gists}
                  </div>
                </div>
              </div>
            </div>
            <RepoList repos ={allRepos}/>
          </div>
          <Footer/>
        </div>
      )
  // return (
  //   <>
  //   
  //     </>
  // )
}

/*
 * Front end side se backend:
 * to whome
 * by who
 * what
 * rating(1-10)
 */