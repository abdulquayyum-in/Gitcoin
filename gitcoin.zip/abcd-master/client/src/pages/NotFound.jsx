import Navbars from "../Components/Navbars"
import notFoundImage from "./notfoundimage.png"
function NotFound() {
  return (
    <>
    <Navbars/>
    {/* <img src="notFoundImage" alt="" /> */}
    <img src={notFoundImage} alt="" className="max-w-4xl m-auto"/>
    </>
    
  )
}

export default NotFound