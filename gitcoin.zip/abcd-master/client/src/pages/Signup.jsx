import React from 'react'
import { Link } from 'react-router-dom';

function Signup() {
  return (
    <>
  <h1>Welcome to gitcoin</h1>
    </>
  )
}

export default Signup