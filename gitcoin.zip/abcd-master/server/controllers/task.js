import express, { Router } from "express"
import authvalidator from "../utils/auth.js";
import mongoose from "mongoose";
import UserSchema from "../models/user.js";
import randomstring from "../utils/randomstring.js";
import RepoData from '../models/Repo.js';
import sendMail from "../utils/sendMail.js";
const router = express.Router()
import { generateEmailTemplate2,generateEmailTemplate } from "../utils/generateHtml.js";
router.post("/assigntask", authvalidator, async (req, res) => {
    try {
        console.log(req.body);
        let admin = await UserSchema.findOne({ _id: req.payload.id })
        // console.log(admin.userRepos);
        let reposdata = await RepoData.findOne({ user: req.payload.id })
        let repos = reposdata.RepoData
        console.log()
        let found = false
        if (req.body.reward > admin.wallet) {
            return res.status(409).json({ error: "You do not have enough amount" })
        }
        repos.forEach((ele) => {
            if (ele.repoName == req.body.repo) {
                found = true
            }
        })
        if (found) {
            admin.wallet = admin.wallet - req.body.reward
            let user = await UserSchema.findOne({ username: req.body.username })
            console.log(user.email);
            let identifier = randomstring(10)
            user.yourTasks.push({
                userName: admin.username,
                userEmail:admin.email,
                userImage:admin.avatarUrl,
                taskname: req.body.taskname,
                deadline: req.body.deadline,
                description: req.body.description,
                reward: req.body.reward,
                repo: req.body.repo,
                isCompleted:false,
                Accepted:"pending",
                identifier: identifier
            })
            admin.givenTasks.push({
                userName: user.username,
                userEmail:user.email,
                userImage:user.avatarUrl,
                taskname: req.body.taskname,
                description: req.body.description,
                deadline: req.body.deadline,
                reward: req.body.reward,
                repo: req.body.repo,
                isCompleted:false,
                Accepted:"pending",
                identifier: identifier
            })
            user.save()
            admin.save()
            res.status(200).json({ success: "Task has been assigned Successfully" })
            let acceptlink = `http://192.168.68.189:6001/api/task/accept/${identifier}?uid=${user._id}&aid=${admin._id}`
            let rejectlink = `http://192.168.68.189:6001/api/task/reject/${identifier}?uid=${user._id}&aid=${admin._id}`
            await sendMail({
                subject: "Gitcoin Application",
                receiver: user.email,
                // taskName, taskDescription, assignedTo,assignedBy,reward,deadline
                html: generateEmailTemplate(req.body.taskname, req.body.description, user.username, admin.username, req.body.reward, req.body.deadline, req.body.repo, acceptlink, rejectlink)
            });
        } else {
            return res.status(409).json({ error: "repo is not in your github" })
        }
    } catch (error) {
        console.log(error)
        res.status(400).json({ error: "Invalid credentials" })
    }
})

router.get("/yourtasks", authvalidator, async (req, res) => {
    try {
        const user = await UserSchema.findOne({ _id: req.payload.id });

        const yourTasks = user.yourTasks;
        res.status(200).json({ yourTasks });
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: "Invalid credentials" });
    }
});

router.get("/giventasks", authvalidator, async (req, res) => {
    try {
        const admin = await UserSchema.findOne({ _id: req.payload.id });
        const givenTasks = admin.givenTasks;
        res.status(200).json({ givenTasks });
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: "Invalid credentials" });
    }
});

router.get("/checktask", authvalidator, async (req, res) => {
    try {
        const user = await UserSchema.findOne({ _id: req.payload.id });
        const yourTasks = user.yourTasks;
        console.log(yourTasks);
        for (const task of yourTasks) {
            // console.log(tas);
            console.log(task.userName);
            const admin = await UserSchema.findOne({ username: task.userName });
            console.log(admin);
            const givenTask = admin.givenTasks
            const merged = await checkPRStatus(task.repo, task.userName, admin.accessToken)
            if (merged) {
                givenTask.forEach(ele => {
                    if (ele.userName == task.userName && ele.repo == task.repo) {
                        let update = ele
                        update.isCompleted = true
                    }
                })
                task.isCompleted = true;
                user.wallet += task.reward;
            } else {
                task.completed = false;
            }
        }
        await user.save();
        res.status(200).json({ yourTasks });
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: "Invalid credentials" });
    }
});


router.get("/accept/:taskid", async (req, res) => {
    try {
        let user = await UserSchema.findOne({ _id: req.query.uid })
        let admin = await UserSchema.findOne({ _id: req.query.aid })
        let yourtask = user.yourTasks
        let giventask = admin.givenTasks
        // console.log(yourtask);
        console.log(req.params.taskid);
        const usertasks = yourtask.find(obj => obj.identifier === req.params.taskid);
        usertasks.Accepted = "Accepted"
        // console.log(object);
        const admintasks = giventask.find(obj => obj.identifier === req.params.taskid);
        admintasks.Accepted = "Accepted"
        console.log(admintasks);
        user.save()
        admin.save()
        res.status(200).json({ success: "Task has been accepted successfully" });
        await sendMail({
            subject: "Gitcoin Application",
            receiver: admin.email,
            // taskName, taskDescription, assignedTo,assignedBy,reward,deadline
            html: `<h1>The task ${admintasks.taskname} has been accepted by ${user.username}</h1>`
        });
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: "Invalid credentials" });
    }
})


router.get("/reject/:taskid", async (req, res) => {
    try {
        let user = await UserSchema.findOne({ _id: req.query.uid })
        let admin = await UserSchema.findOne({ _id: req.query.aid })
        let yourtask = user.yourTasks
        let giventask = admin.givenTasks
        // console.log(yourtask);
        console.log(req.params.taskid);
        const usertasks = yourtask.find(obj => obj.identifier === req.params.taskid);
        usertasks.Accepted = "rejected"
        // console.log(object);
        const admintasks = giventask.find(obj => obj.identifier === req.params.taskid);
        admintasks.Accepted = "rejected"
        console.log(admintasks);
        user.save()
        admin.save()
        res.status(200).json({ success: "Task status has been rejected successfully" });
        await sendMail({
            subject: "Gitcoin Application",
            receiver: admin.email,
            html: `<h1>The task ${admintasks.taskname} has been rejected by ${user.username}</h1>`
        });
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: "Invalid credentials" });
    }
})


export default router