import express from "express"
const router = express.Router()
import gitusers from "../functions/gituser.js";
import { verifycode, getrepos } from "../functions/index.js";
import UserSchema from "../models/user.js";
import generator from "generate-password"
import RepoData from '../models/Repo.js';
import bcrypt from "bcrypt"
import axios from "axios"
import sendMail from "../utils/sendMail.js";
import generateToken from "../utils/generateToken.js";
import authvalidator from "../utils/auth.js";
import { generateEmailTemplate2, generateEmailTemplate } from "../utils/generateHtml.js";


//This route is used for Oauth verification
router.post("/verified", async (req, res) => {
  try {
    const code = req.query.code;
    // console.log(code);
    let data = await verifycode(code)
    // console.log(data);
    let { user, allrepo, publicrepo, email, access_token } = data
    
    console.log(user);
    let userFound = await UserSchema.findOne({ username: user.login })
    if (userFound) {
      let repodata = await RepoData.findOne({ user: userFound._id })
      repodata.RepoData = allrepo
      repodata.PublicRepos = publicrepo
      await repodata.save()
      userFound.accessToken = access_token
      userFound.save()
      let payload = {
        id: userFound._id,
        email: userFound.email
      }
      let token = generateToken(payload);
      console.log(token);
      return res.status(200).json({ success: "Successfully login 1", token })
    }
    let password1 = generator.generate({
      length: 12,
      strict: true
    })
    let password = await bcrypt.hash(password1, 12)
    console.log(password);
    let userSchema = new UserSchema({
      name: user.name,
      bio:user.bio,
      twitter_username:user.twitter_username,
      username: user.login,
      email: email,
      password: password,
      accessToken: access_token,
      avatarUrl: user.avatar_url

    })
    let usecase = await userSchema.save()
    let id = usecase._id
    let repos = new RepoData({
      RepoData: allrepo,
      PublicRepos: publicrepo,
      user: id
    })
    await repos.save()
    await sendMail({
      subject: "Gitcoin Application ",
      receiver: email,
      html: generateEmailTemplate2(user.login, password1)
    });

    let payload = {
      id: id,
      email: email
    }
    let token = generateToken(payload);
    res.status(200).json({ message: "Successfully added the task", token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error 2 from login" });
  }
})


//fOR THE purpose of login
router.post("/login", async (req, res) => {
  console.log(req.body);
  try {
    let userFound = await UserSchema.findOne({ username: req.body.username })
    console.log(userFound);
    if (!userFound) {
      return res.status(401).json({ error: "Unauthorised Access" })
    }
    let matchPassword = bcrypt.compare(req.body.password, userFound.password);
    if (!matchPassword) {
      return res.status(401).json({ error: "Unauthorised Access" });
    }
    let data = await getrepos(userFound.accessToken)
    let { allrepo, publicrepo } = data
    let repodata = await RepoData.findOne({ user: userFound._id })
    repodata.RepoData = allrepo
    repodata.PublicRepos = publicrepo
    await repodata.save()
    let payload = {
      id: userFound._id,
      email: userFound.email
    }
    let token = generateToken(payload);
    res.status(200).json({ success: "Login is Successful", token });


  } catch (error) {
    res.status(500).json({ error: "Internal Server Error 2 from login" });
  }
})


//For getting the info of the user

router.get("/info", authvalidator, async (req, res) => {
  try {
    const user = await UserSchema.findOne({ _id: req.payload.id });
    const accessToken = user.accessToken
    const user_url = 'https://api.github.com/user';
    const user_response = await axios.get(user_url, {
      headers: {
        Authorization: `Token ${accessToken}`,
        Accept: 'application/json'
      }
    });
    const user_repo_url = `https://api.github.com/search/repositories?q=user:${user.username}`;
    // console.log(userFound);
    const user_repos_response = await axios.get(user_repo_url, {
      headers: {
        Authorization: `Token ${accessToken}`,
        Accept: 'application/json'
      },
    });

    let userrepo = user_repos_response.data.items
    let userData = user_response.data
    let obj = {
      userrepo, userData
    }
    res.status(200).json({ sucess: 'data fetched successfully', obj })
  } catch (error) {
    console.log(error);
    res.status(409).json({ sucess: 'Data fetching failed' })
  }

})

//For updating the wallet

router.post("/updatewallet", authvalidator, async (req, res) => {
  try {
    const user = await UserSchema.findOne({ _id: req.payload.id });
    user.wallet = user.wallet + req.body.money
    const transcation = user.transaction
    const transcation1 = {
      credited: req.body.money,
      debited: "0",
      balance: user.wallet,
      date: new Date()
    }
    transcation.push(transcation1)
    user.save()
    res.status(200).json({ success: "Amount is added" });
    return await sendMail({
      subject: "Gitcoin Application ",
      receiver: user.email,
      html: `<h1>This amount of ${req.body.money + "/-"} has been added by to your wallet and the total amount is ${user.wallet + "/-"}</h1>`
    });

  } catch (error) {
    console.log(error)
    res.status(401).json({ success: "Transaction Failed" });


  }
})

//for the purppose of transaction history

router.get("/transaction", authvalidator, async (req, res) => {
  try {
    const user = await UserSchema.findOne({ _id: req.payload.id });
    const usertransaction = user.transaction
    res.status(200).json({ success: "Transaction History is fetched", usertransaction });
  } catch (error) {
    console.log(error)
    res.status(400).json({ error: "Invalid Credentials" });

  }
})

router.get("/wallet", authvalidator, async (req, res) => {
  try {
    const user = await UserSchema.findOne({ _id: req.payload.id });
    const userwallet = user.wallet
    res.status(200).json({ success: "Wallet Amount is fetched", userwallet });
  } catch (error) {
    console.log(error)
    res.status(401).json({ error: "Invalid Credentials" });

  }
})


router.get("/search/:username", authvalidator, async (req, res) => {
  try {
    let text = req.params.username
    text = text.trim();
    text = new RegExp(text, "i");
    const response = await UserSchema.find({ name: { $regex: text } })
    console.log(response[0])
    if(response[0]==undefined){      
      res.status(409).json({response})
    }else{
      res.send(response);
    }
  } catch (error) {
    console.log(error)
    res.status(401).json({ error: "Failed" });


  }
}) 

router.post("/debitwallet", authvalidator, async (req, res) => {
  try {
    const user = await UserSchema.findOne({ _id: req.payload.id });
    console.log(req.body)
    user.wallet = user.wallet - (+req.body.money)
    const transcation = user.transaction
    const transcation1 = {
      credited: "0",
      debited:  req.body.money,
      balance: user.wallet,
      date: new Date()
    }
    transcation.push(transcation1)
    user.save()
    res.status(200).json({ success: "Amount is will be credited into your account in 3-5 days" });
    await sendMail({
      subject: "Gitcoin Application ",
      receiver: user.email,
      html: `<h1>This amount of ${req.body.money + "/-"} has been debited by to your wallet and the total amount is ${user.wallet + "/-"}</h1>`
    });

  } catch (error) {
    console.log(error)
    res.status(401).json({ success: "Transaction Failed" });


  }
})

router.get("/repodata", authvalidator, async (req, res) => {
  try {
    let repodata = await RepoData.findOne({ user: req.payload.id })
      console.log(repodata);
      const allrepodata = repodata.RepoData;
      res.status(200).json({ success:"repo data fetched successfully" ,allrepodata});
  } catch (error) {
      console.log(error);
      res.status(400).json({ error: "Invalid credentials" });
  }
});

router.get("/info/:username", authvalidator, async (req, res) => {
  try {
    console.log("first")
    const username = req.params.username
    const response = await gitusers(username)
    console.log("hello")    
    res.send(response)
  } catch (error) {
    console.log(error);
    res.status(409).json({ sucess: 'Data fetching failed' })
  }

})

 export default router