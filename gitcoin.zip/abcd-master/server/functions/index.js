import config from "config"
import { filterpubRepoData, filterRepoData } from "../utils/filter.js";
import axios from "axios"

let clientid = config.get("CLIENT_ID")
console.log(clientid);

async function verifycode(code){
    try {
    const token_url = `https://github.com/login/oauth/access_token?client_id=${config.get("CLIENT_ID")}&client_secret=${config.get("CLIENT_SECRET")}&code=${code}`;
    const response = await axios.post(token_url, {}, {
      headers: {
        Accept: 'application/json'
      }
    });
    const access_token = response.data.access_token;
    
    const user_url = 'https://api.github.com/user';
    const user_response = await axios.get(user_url, {
      headers: {
        Authorization: `Token ${access_token}`,
        Accept: 'application/json'
      }
    });
    const user = user_response.data;
    console.log(user);

    const user_repo_url = `https://api.github.com/search/repositories?q=user:${user.login}`;
    const user_repos_response = await axios.get(user_repo_url, {
      headers: {
        Authorization: `Token ${access_token}`,
        Accept: 'application/json'
      }

    });

    const allrepo = filterRepoData(user_repos_response.data)
    const publicrepo = filterpubRepoData(user_repos_response.data)


    let email_response = await axios.get("https://api.github.com/user/emails", {
      headers: {
        Authorization: `Token ${access_token}`,
        Accept: 'application/json'
      }
    });
    let email = email_response.data[0].email
    return {user,allrepo,publicrepo,email,access_token}
    // console.log(email);
    } catch (error) {
    console.log(error)
    }
} 

async function getrepos(accessToken){
    const user_repo_url = `https://api.github.com/search/repositories?q=user:${user.login}`;
    const user_repos_response = await axios.get(user_repo_url, {
      headers: {
        Authorization: `Token ${accesstoken}`,
        Accept: 'application/json'
      }
      
    });

    const allrepo = filterRepoData(user_repos_response.data)
    const publicrepo = filterpubRepoData(user_repos_response.data)
    return {allrepo,publicrepo}

}

export {verifycode,getrepos}