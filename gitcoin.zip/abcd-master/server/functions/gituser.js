import axios from "axios"
import config from "config"



async function gitusers(user){
 let {data} = await axios.get(`https://api.github.com/users/${user}`
,{
        auth:{
            username: config.get("USERNAME"),
            password: config.get("GIT_ID")
        } 
    })

    
    let repodata = await axios.get(`https://api.github.com/users/${user}/repos`,{
        auth:{
            username: config.get("USERNAME"),
            password: config.get("GIT_ID"),
        } 
    })
    const userData = data
    const repositories = repodata.data
    

    return {userData,repositories}

}
// await gitusers("anwarali08")
export default gitusers

