import express from "express"
import "./dbConnect.js"
import cors from "cors"
import config from 'config';
import userRoute from "./controllers/user.js"
import taskRoute from "./controllers/task.js"

const app = express()
const port = config.get("PORT")

app.use(cors())
app.use(express.json())

app.get("/",(req,res)=>{
    res.send("server is up")
})

app.use("/api/user",userRoute)
app.use("/api/task",taskRoute)

app.listen(port,()=>{
    console.log("Server started at",port)
})