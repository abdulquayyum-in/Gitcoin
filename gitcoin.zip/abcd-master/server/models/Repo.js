import { Schema } from "mongoose";
import mongoose from "mongoose";

const repoData = Schema({
    RepoData: [{
        repoName :{
            type:String,
            required:true
          },
          repoURL :{
            type:String,
            required:true
          },
          isPrivate :{
            type:Boolean,
            required:true
          }
    }],
    PublicRepos:[{
        repoName :{
            type:String,
            required:true
          },
          repoURL :{
            type:String,
            required:true
          },
          isPrivate :{
            type:Boolean,
            required:true
          }
    }],
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "UserSchema"
    }
})

let RepoData = mongoose.model("RepoData", repoData, "repoData")
export default RepoData