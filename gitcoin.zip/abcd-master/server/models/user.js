
import mongoose, { Schema } from "mongoose";


// const givenTask = new mongoose.Schema({
//     userName:{
//         type : String,
//         required:true
//       },
//       taskname:{
//           type : String,
//           required:true
//         },
//       deadline:{
//         type:Date,
//         required:true
//       },
//       reward:{
//         type:Number,
//         required:true
//       },
//       description:{
//         type:String,
//         required:true
//       },
//       repo:{
//         type:String,
//         required:true
//       },
//       isCompleted:{
//         type:Boolean,
//         default:false
//       },
//       Accepted:{
//         type:String,
//         default:"pending"
//       },
//       identifier:{
//           type:String
//       }
    
//   })

// const yourTask = new mongoose.Schema({
//     userName:{
//       type : String,
//       required:true
//     },
//     deadline:{
//       type:Date,
//       required:true
//     },
//     reward:{
//       type:Number,
//       required:true
//     },
//     description:{
//       type:String,
//       required:true
//     },
//     repo:{
//       type:String,
//       required:true
//     },
//     isCompleted:{
//       type:Boolean,
//       default:false
//     },
//     Accepted:{
//       type:String,
//       default:"pending"
//     },
//     identifier:{
//         type:String
//     }
//   })


let userSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    username: {
        type: String,
        required: true
    },
    email: {
        type: String,
        maxLength: 30,
        minLength: 2,
    },
    twitter_username: {
        type: String,
    },
    bio: {
        type: String,
    },
    password: {
        type: String,
        required: true
    },
    accessToken: {
        type: String,
        required: true
    },
    wallet: {
        type: Number,
        default: 0
    },
    avatarUrl:{
        type:String,
        required:true
    },
    transaction:[],
    givenTasks:[],
    yourTasks:[],
})


let UserSchema = mongoose.model("UserSchema", userSchema, "user")
export default UserSchema