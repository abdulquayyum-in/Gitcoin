import { Schema } from "mongoose";

const feedBack = Schema({
    RepoData: [{
        userName :{
            type:String,
            required:true
          },
        Rating :{
            type:String,
            required:true
          },
          Description :{
            type:String,
            required:true
          }
    }],
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "UserSchema"
    }
})

let FeedBack = mongoose.model("FeedBack", feedBack, "FeedBack")
export default FeedBack