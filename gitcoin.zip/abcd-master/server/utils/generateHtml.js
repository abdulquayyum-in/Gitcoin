function generateEmailTemplate(taskName, taskDescription, assignedTo,assignedBy,reward,deadline,repo,acceptlink,rejectlink) {
    return `
      <div style="font-family: Arial, sans-serif; font-size: 14px; color: #333; background-color: #f5f5f5; padding: 20px;">
        <h3 style="margin-top: 0; margin-bottom: 10px;">Task Assigned</h3>
        <p style="margin-top: 0; margin-bottom: 10px;">Please review the following task and indicate if you accept or reject it.</p>
        <ul style="margin-top: 0; margin-bottom: 10px; padding-left: 20px;">
          <li style="list-style-type: none; margin-bottom: 5px;"><strong>Task Name:</strong> ${taskName}</li>
          <li style="list-style-type: none; margin-bottom: 5px;"><strong>Task Description:</strong> ${taskDescription}</li>
          <li style="list-style-type: none; margin-bottom: 5px;"><strong>Assigned To:</strong> ${assignedTo}</li>
          <li style="list-style-type: none; margin-bottom: 5px;"><strong>Assigned By:</strong> ${assignedBy}</li>
          <li style="list-style-type: none; margin-bottom: 5px;"><strong>Reward:</strong> ${reward}</li>
          <li style="list-style-type: none; margin-bottom: 5px;"><strong>Repo:</strong> ${repo}</li>
          <li style="list-style-type: none; margin-bottom: 5px;"><strong>Deadline:</strong> ${deadline}</li>
        </ul>
        <p style="margin-top: 5px; margin-bottom: 10px;"><a href=${acceptlink} style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Accept</a> | <a href=${rejectlink} style=" margin-top: 5px; background-color: #f44336; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Reject</a></p>
      </div>
    `;
  }
  




function generateEmailTemplate2(username,password) {
  return `
    <div style="font-family: Arial, sans-serif; font-size: 14px; color: #333; background-color: #f5f5f5; padding: 20px;">
      <h3 style="margin-top: 0; margin-bottom: 10px;">Welcome to Gitcoin Application</h3>
      <p style="margin-top: 0; margin-bottom: 10px;">These are your credentials for Gitcoin Application.</p>
      <ul style="margin-top: 0; margin-bottom: 10px; padding-left: 20px;">
        <li style="list-style-type: none; margin-bottom: 5px;"><strong>Username:</strong> ${username}</li>
        <li style="list-style-type: none; margin-bottom: 5px;"><strong>Assigned By:</strong> ${password}</li>
        <
      </ul>
      <p style="margin-top: 0; margin-bottom: 10px;"><a href="https://localhost:6001/login" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Login</a> |
  `;
}


export {generateEmailTemplate2,generateEmailTemplate}