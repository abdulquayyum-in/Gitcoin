let filterRepoData = (data)=>{
    let allRepoData = []
    for(let i=0;i<data.items.length;i++){
        let filteredData = {}
        filteredData.repoName = data.items[i].name
        filteredData.repoURL = data.items[i].html_url
        filteredData.isPrivate = data.items[i].private
        allRepoData.push(filteredData)
    }
    return allRepoData
}

const filterpubRepoData = (data) => {
    const allRepoData = [];
    for (let i = 0; i < data.items.length; i++) {
      if (!data.items[i].private) {
        let filteredData = {};
        filteredData.repoName = data.items[i].name;
        filteredData.repoURL = data.items[i].html_url;
        filteredData.isPrivate = data.items[i].private;
        allRepoData.push(filteredData);
      }
    }
    return allRepoData;
  };

export {filterRepoData,filterpubRepoData}